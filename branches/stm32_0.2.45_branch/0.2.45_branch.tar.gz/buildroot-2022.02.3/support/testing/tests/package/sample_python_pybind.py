#!/usr/bin/env python
import example
print(example.add(1, 2))
print(example.says)
