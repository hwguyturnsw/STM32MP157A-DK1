from colorzero import Color

red = Color('red')
green = Color('lime')
blue = Color('blue')
assert(red.rgb == (1.0, 0.0, 0.0))
assert(green.rgb == (0.0, 1.0, 0.0))
assert(blue.rgb == (0.0, 0.0, 1.0))
