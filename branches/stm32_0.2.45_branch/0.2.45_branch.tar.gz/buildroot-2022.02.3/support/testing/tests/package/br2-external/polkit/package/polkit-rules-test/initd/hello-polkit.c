#include <stdio.h>

int main(void){
    printf("Hello polkit!\n");
    return 0;
}
